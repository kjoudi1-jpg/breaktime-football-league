let matches = [];

let editingId = null;


/* -----------------------
   NAVIGATION
----------------------- */

document.querySelectorAll(".navBtn").forEach(function(button) {

  button.addEventListener("click", function() {

    document.querySelectorAll(".navBtn").forEach(function(btn) {
      btn.classList.remove("active");
    });

    button.classList.add("active");

    document.querySelectorAll(".page").forEach(function(page) {
      page.classList.remove("active");
    });

    const page = document.getElementById(
      button.dataset.page
    );

    page.classList.add("active");

  });

});


/* -----------------------
   MODAL
----------------------- */

const modal = document.getElementById("modal");

document.getElementById("addMatch").addEventListener(
  "click",
  openAddMatch
);

document.getElementById("adminAddMatch").addEventListener(
  "click",
  openAddMatch
);

document.getElementById("closeModal").addEventListener(
  "click",
  closeModal
);


function openAddMatch() {

  editingId = null;

  document.getElementById("modalHeading").textContent =
    "Add Match";

  document.getElementById("date").value = "";

  document.getElementById("matchName").value =
    "League Match";

  document.getElementById("home").value =
    "Baba FC";

  document.getElementById("away").value =
    "Dr Pepper FC";

  document.getElementById("homeScore").value = 0;

  document.getElementById("awayScore").value = 0;

  document.getElementById("scorers").value = "";

  document.getElementById("assists").value = "";

  document.getElementById("mvp").value = "";

  modal.classList.remove("hidden");
}


function closeModal() {

  modal.classList.add("hidden");

}


/* -----------------------
   SAVE MATCH
----------------------- */

document.getElementById("saveMatch").addEventListener(
  "click",
  function() {

    const home =
      document.getElementById("home").value;

    const away =
      document.getElementById("away").value;

    if (home === away) {

      alert("The teams must be different.");

      return;
    }


    const newMatch = {

      id: editingId || Date.now(),

      date:
        document.getElementById("date").value ||
        "2026-10-03",

      name:
        document.getElementById("matchName").value ||
        "League Match",

      home: home,

      away: away,

      homeScore:
        Number(
          document.getElementById("homeScore").value
        ),

      awayScore:
        Number(
          document.getElementById("awayScore").value
        ),

      scorers:
        document.getElementById("scorers").value,

      assists:
        document.getElementById("assists").value,

      mvp:
        document.getElementById("mvp").value

    };


    if (editingId) {

      matches = matches.map(function(match) {

        if (match.id === editingId) {
          return newMatch;
        }

        return match;

      });

    } else {

      matches.push(newMatch);

    }


    closeModal();

    renderEverything();

  }
);


/* -----------------------
   MATCHES
----------------------- */

function renderMatches() {

  const list =
    document.getElementById("matchList");

  list.innerHTML = "";


  if (matches.length === 0) {

    list.innerHTML = `
      <div class="box">
        <h3>No matches yet</h3>
        <p>Add your first match using "Add Match".</p>
      </div>
    `;

    return;
  }


  matches.forEach(function(match) {

    const div =
      document.createElement("div");

    div.className = "match";

    div.innerHTML = `

      <div class="matchHeader">
        <span>${match.date}</span>
        <span>${match.name}</span>
      </div>

      <div class="matchScore">

        <div class="team">
          ${match.home}
        </div>

        <div class="score">
          ${match.homeScore} - ${match.awayScore}
        </div>

        <div class="team away">
          ${match.away}
        </div>

      </div>

      <div class="matchDetails">

        ${
          match.scorers
            ? "⚽ <b>Scorers:</b> " +
              match.scorers
            : ""
        }

        ${
          match.assists
            ? "<br>🎯 <b>Assists:</b> " +
              match.assists
            : ""
        }

        ${
          match.mvp
            ? "<br>🏆 <b>MVP:</b> " +
              match.mvp
            : ""
        }

        <br>

        <button
          class="edit"
          data-id="${match.id}">
          ✏️ Edit Match
        </button>

      </div>

    `;

    list.appendChild(div);

  });


  document.querySelectorAll(".edit").forEach(
    function(button) {

      button.addEventListener("click", function() {

        editMatch(
          Number(button.dataset.id)
        );

      });

    }
  );

}


/* -----------------------
   EDIT MATCH
----------------------- */

function editMatch(id) {

  const match =
    matches.find(function(item) {
      return item.id === id;
    });

  if (!match) return;

  editingId = id;

  document.getElementById("modalHeading").textContent =
    "Edit Match";

  document.getElementById("date").value =
    match.date;

  document.getElementById("matchName").value =
    match.name;

  document.getElementById("home").value =
    match.home;

  document.getElementById("away").value =
    match.away;

  document.getElementById("homeScore").value =
    match.homeScore;

  document.getElementById("awayScore").value =
    match.awayScore;

  document.getElementById("scorers").value =
    match.scorers;

  document.getElementById("assists").value =
    match.assists;

  document.getElementById("mvp").value =
    match.mvp;

  modal.classList.remove("hidden");

}


/* -----------------------
   LEAGUE TABLE
----------------------- */

function createTeam(name) {

  return {

    name: name,

    played: 0,

    wins: 0,

    draws: 0,

    losses: 0,

    goalsFor: 0,

    goalsAgainst: 0,

    points: 0

  };

}


function getTable() {

  const table = {

    "Baba FC": createTeam("Baba FC"),

    "Dr Pepper FC":
      createTeam("Dr Pepper FC")

  };


  matches.forEach(function(match) {

    const home = table[match.home];

    const away = table[match.away];

    if (!home || !away) return;


    home.played++;
    away.played++;

    home.goalsFor += match.homeScore;
    home.goalsAgainst += match.awayScore;

    away.goalsFor += match.awayScore;
    away.goalsAgainst += match.homeScore;


    if (match.homeScore > match.awayScore) {

      home.wins++;
      away.losses++;

      home.points += 3;

    }

    else if (
      match.homeScore < match.awayScore
    ) {

      away.wins++;
      home.losses++;

      away.points += 3;

    }

    else {

      home.draws++;
      away.draws++;

      home.points++;
      away.points++;

    }

  });


  return Object.values(table);

}


function renderTable() {

  const tbody =
    document.getElementById("leagueTable");

  tbody.innerHTML = "";


  getTable().forEach(function(team, index) {

    const gd =
      team.goalsFor -
      team.goalsAgainst;


    const row =
      document.createElement("tr");

    row.innerHTML = `

      <td>${index + 1}</td>

      <td><b>${team.name}</b></td>

      <td>${team.played}</td>

      <td>${team.wins}</td>

      <td>${team.draws}</td>

      <td>${team.losses}</td>

      <td>${team.goalsFor}</td>

      <td>${team.goalsAgainst}</td>

      <td>${gd}</td>

      <td><b>${team.points}</b></td>

    `;

    tbody.appendChild(row);

  });

}


/* -----------------------
   TOP NUMBERS
----------------------- */

function renderNumbers() {

  let goals = 0;

  matches.forEach(function(match) {

    goals +=
      match.homeScore +
      match.awayScore;

  });


  document.getElementById("matchTotal")
    .textContent = matches.length;

  document.getElementById("goalTotal")
    .textContent = goals;

}


/* -----------------------
   PLAYER STATISTICS
----------------------- */

function countPlayers(values) {

  const result = {};

  values.forEach(function(text) {

    if (!text) return;

    text
      .split(",")
      .map(function(name) {
        return name.trim();
      })
      .filter(Boolean)
      .forEach(function(name) {

        if (!result[name]) {
          result[name] = 0;
        }

        result[name]++;

      });

  });

  return result;

}


function showPlayerStats(
  elementId,
  data,
  suffix
) {

  const element =
    document.getElementById(elementId);

  element.innerHTML = "";


  const players =
    Object.entries(data)
      .sort(function(a, b) {
        return b[1] - a[1];
      });


  if (players.length === 0) {

    element.innerHTML =
      "<p>No data yet.</p>";

    return;
  }


  players.forEach(function(item) {

    const row =
      document.createElement("div");

    row.className = "statRow";

    row.innerHTML = `

      <span>${item[0]}</span>

      <span class="statValue">
        ${item[1]} ${suffix}
      </span>

    `;

    element.appendChild(row);

  });

}


function renderStats() {

  const scorers =
    matches.map(function(match) {
      return match.scorers;
    });

  const assists =
    matches.map(function(match) {
      return match.assists;
    });

  const mvps =
    matches.map(function(match) {
      return match.mvp;
    });


  showPlayerStats(
    "goalsStats",
    countPlayers(scorers),
    "goals"
  );

  showPlayerStats(
    "assistsStats",
    countPlayers(assists),
    "assists"
  );

  showPlayerStats(
    "mvpStats",
    countPlayers(mvps),
    "MVP"
  );


  const winBox =
    document.getElementById("winStats");

  winBox.innerHTML = "";


  getTable().forEach(function(team) {

    const percentage =
      team.played === 0
        ? 0
        : Math.round(
            team.wins /
            team.played *
            100
          );


    const row =
      document.createElement("div");

    row.className = "statRow";

    row.innerHTML = `

      <span>${team.name}</span>

      <span class="statValue">
        ${percentage}%
      </span>

    `;

    winBox.appendChild(row);

  });

}


/* -----------------------
   RESET
----------------------- */

document.getElementById("resetLeague")
  .addEventListener(
    "click",
    function() {

      const answer =
        confirm(
          "Reset the entire league? All matches will be removed."
        );

      if (!answer) return;

      matches = [];

      renderEverything();

    }
  );


/* -----------------------
   RENDER EVERYTHING
----------------------- */

function renderEverything() {

  renderTable();

  renderMatches();

  renderNumbers();

  renderStats();

}


/* START EMPTY */

renderEverything();